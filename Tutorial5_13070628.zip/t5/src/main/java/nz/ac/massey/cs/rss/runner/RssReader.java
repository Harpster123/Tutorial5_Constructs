package nz.ac.massey.cs.rss.runner;

import nz.ac.massey.cs.sdc.parsers.Rss;
import nz.ac.massey.cs.sdc.parsers.RssItem;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.util.List;

public class RssReader {
    public static void main(String[] args) {
        try {
            // Load the XML file
            File file = new File("media-technology.xml");


            JAXBContext jaxbContext = JAXBContext.newInstance(Rss.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();


            Rss rss = (Rss) unmarshaller.unmarshal(file);

            // Get the list of items
            List<RssItem> items = rss.getChannel().getItem();

            // Loop through the items and print the details
            for (RssItem item : items) {

                StringBuilder output = new StringBuilder();

                // Iterate over the mixed list of title, description, and link
                for (Object obj : item.getTitleOrDescriptionOrLink()) {
                    if (obj instanceof JAXBElement) {
                        JAXBElement<?> element = (JAXBElement<?>) obj;
                        String name = element.getName().getLocalPart();
                        Object value = element.getValue();

                        // Handle each element based on its name and type
                        switch (name) {
                            case "title":
                            case "description":
                            case "link":
                                if (value instanceof String) {
                                    output.append(name + ": " + value + "\n");
                                }
                                break;

                            default:
                                break;
                        }
                    }
                }

                output.append("\n");

                // Print the formatted output
                System.out.println(output.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
